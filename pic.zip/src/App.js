import UploadImage from './UploadImage';
import './App.css';


function App() {
  return (
   <UploadImage />
  );
}

export default App;
